import re

# Conversation text
conversation = """
Title: Exploring Network Effects: A Socratic Dialogue

Host: Welcome to today's podcast, where we'll be exploring the fascinating concept of network effects. To help us dive into this topic, we have two characters joining us today: Alex, a curious individual eager to learn about network effects, and Sam, an expert in the field. Let's begin our Socratic dialogue.

Alex: Hi Sam, I've been hearing a lot about network effects lately, but I'm not quite sure what they are. Can you explain the concept to me?

# ... (Rest of the conversation)
"""

# Split the conversation into lines
lines = conversation.split("\n")

# Initialize variables to store title, speakers, and conversation segments
title = None
speakers = set()
current_speaker = None
conversation_segments = {}

# Regular expressions for matching titles and speakers
title_pattern = re.compile(r"Title:\s*(.*)")
speaker_pattern = re.compile(r"([^:]+):\s*(.*)")

# Iterate through the lines of the conversation
for line in lines:
    # Match title
    title_match = title_pattern.match(line)
    if title_match:
        title = title_match.group(1).strip()
        continue

    # Match speaker
    speaker_match = speaker_pattern.match(line)
    if speaker_match:
        current_speaker, message = speaker_match.groups()
        speakers.add(current_speaker)
        if current_speaker not in conversation_segments:
            conversation_segments[current_speaker] = []
        conversation_segments[current_speaker].append(message.strip())
    elif current_speaker:
        # Append to the current speaker's segment
        conversation_segments[current_speaker][-1] += f"\n{line.strip()}"

# Print the title
print(f"Title: {title}\n")

# Print each speaker's segments
for speaker, segments in conversation_segments.items():
    print(f"{speaker}:")
    for i, segment in enumerate(segments, start=1):
        print(f"Segment {i}: {segment}\n")
