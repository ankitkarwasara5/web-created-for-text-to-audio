import requests

url = "https://api.genny.lovo.ai/api/v1/speakers?sort=displayName%3A1"

headers = {
    "accept": "application/json",
    "X-API-KEY": "e6302ca5-4fb3-4e12-a461-80b821e3dc4f"
}

response = requests.get(url, headers=headers)

print(response.text)