from flask import Flask, render_template, request, g, Response, Blueprint, jsonify
from gtts import gTTS
import io
import logging
from setup_log import create_logger
from logging.handlers import RotatingFileHandler
import time

bp = Blueprint('routes', __name__)

app = Flask(__name__)

# @app.before_request
# def before_request():
#     g.request_id = str(uuid.uuid4())

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/convert', methods=['POST'])
def convert():
    error = None
    if 'text' in request.form:
        text = request.form['text']
        if text.strip():  # Check if the input text is not empty or contains only whitespace
            logging.info('Text received from request')
            start_time = time.time()
            language = 'en'
            slow = False
            tts = gTTS(text=text, lang=language, slow=slow)
            logging.info('Text converted to audio')
            audio_data = io.BytesIO()
            tts.write_to_fp(audio_data)
            audio_data.seek(0)
            logging.info('Sending audio response')
            end_time = time.time()
            elapsed_time = end_time - start_time
            logging.info(f'Time taken for conversion: {elapsed_time} seconds')
            return Response(audio_data.read(), content_type='audio/mpeg')
            
        else:
            error = 'Input text is empty'
            logging.error('Error: Empty input text')

    else:
        error = 'No text submitted'
        logging.error('Error: No text submitted')
    return render_template('index.html', error=error)

@bp.route('/converts', methods=['POST'])
def converts():
    error = None
    if 'text' in request.form:
        text = request.form['text']
        if text.strip():  # Check if the input text is not empty or contains only whitespace
            logging.info('Text received from request')
            start_time = time.time()
            language = 'en'
            slow = False
            tts = gTTS(text=text, lang=language, slow=slow)
            logging.info('Text converted to audio')
            audio_data = io.BytesIO()
            tts.write_to_fp(audio_data)
            audio_data.seek(0)
            logging.info('Sending audio response')
            end_time = time.time()
            elapsed_time = end_time - start_time
            logging.info(f'Time taken for conversion: {elapsed_time} seconds')
            return Response(audio_data.read(), content_type='audio/mpeg')

        else:
            error = 'Input text is empty'
            logging.warning('Warning: Empty input text')

    else:
        error = 'No text submitted'
        logging.error('Error: No text submitted')
    return render_template('index.html', error=error)     

logging = create_logger(g)
# # Check the response content

# app = Flask(__name__)

# Register the Blueprint
app.register_blueprint(bp)

if __name__ == '__main__':
    app.run(debug=True)
